/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jun 15, 2017 3:26:18 PM                     ---
 * ----------------------------------------------------------------
 */
package com.powercap.core.jalo;

import com.powercap.core.constants.PowerCapCoreConstants;
import com.powercap.core.jalo.ApparelProduct;
import com.powercap.core.jalo.ApparelSizeVariantProduct;
import com.powercap.core.jalo.ApparelStyleVariantProduct;
import com.powercap.core.jalo.ElectronicsColorVariantProduct;
import de.hybris.platform.jalo.GenericItem;
import de.hybris.platform.jalo.Item;
import de.hybris.platform.jalo.Item.AttributeMode;
import de.hybris.platform.jalo.JaloBusinessException;
import de.hybris.platform.jalo.JaloInvalidParameterException;
import de.hybris.platform.jalo.JaloSystemException;
import de.hybris.platform.jalo.SessionContext;
import de.hybris.platform.jalo.c2l.C2LManager;
import de.hybris.platform.jalo.c2l.Language;
import de.hybris.platform.jalo.extension.Extension;
import de.hybris.platform.jalo.product.Product;
import de.hybris.platform.jalo.type.ComposedType;
import de.hybris.platform.jalo.type.JaloGenericCreationException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

/**
 * Generated class for type <code>PowerCapCoreManager</code>.
 */
@SuppressWarnings({"deprecation","unused","cast","PMD"})
public abstract class GeneratedPowerCapCoreManager extends Extension
{
	protected static final Map<String, Map<String, AttributeMode>> DEFAULT_INITIAL_ATTRIBUTES;
	static
	{
		final Map<String, Map<String, AttributeMode>> ttmp = new HashMap();
		Map<String, AttributeMode> tmp = new HashMap<String, AttributeMode>();
		tmp.put("TopSeller", AttributeMode.INITIAL);
		tmp.put("offers", AttributeMode.INITIAL);
		tmp.put("discount", AttributeMode.INITIAL);
		ttmp.put("de.hybris.platform.jalo.product.Product", Collections.unmodifiableMap(tmp));
		DEFAULT_INITIAL_ATTRIBUTES = ttmp;
	}
	@Override
	public Map<String, AttributeMode> getDefaultAttributeModes(final Class<? extends Item> itemClass)
	{
		Map<String, AttributeMode> ret = new HashMap<>();
		final Map<String, AttributeMode> attr = DEFAULT_INITIAL_ATTRIBUTES.get(itemClass.getName());
		if (attr != null)
		{
			ret.putAll(attr);
		}
		return ret;
	}
	
	public ApparelProduct createApparelProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( PowerCapCoreConstants.TC.APPARELPRODUCT );
			return (ApparelProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelProduct createApparelProduct(final Map attributeValues)
	{
		return createApparelProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ApparelSizeVariantProduct createApparelSizeVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( PowerCapCoreConstants.TC.APPARELSIZEVARIANTPRODUCT );
			return (ApparelSizeVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelSizeVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelSizeVariantProduct createApparelSizeVariantProduct(final Map attributeValues)
	{
		return createApparelSizeVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ApparelStyleVariantProduct createApparelStyleVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( PowerCapCoreConstants.TC.APPARELSTYLEVARIANTPRODUCT );
			return (ApparelStyleVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ApparelStyleVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ApparelStyleVariantProduct createApparelStyleVariantProduct(final Map attributeValues)
	{
		return createApparelStyleVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	public ElectronicsColorVariantProduct createElectronicsColorVariantProduct(final SessionContext ctx, final Map attributeValues)
	{
		try
		{
			ComposedType type = getTenant().getJaloConnection().getTypeManager().getComposedType( PowerCapCoreConstants.TC.ELECTRONICSCOLORVARIANTPRODUCT );
			return (ElectronicsColorVariantProduct)type.newInstance( ctx, attributeValues );
		}
		catch( JaloGenericCreationException e)
		{
			final Throwable cause = e.getCause();
			throw (cause instanceof RuntimeException ?
			(RuntimeException)cause
			:
			new JaloSystemException( cause, cause.getMessage(), e.getErrorCode() ) );
		}
		catch( JaloBusinessException e )
		{
			throw new JaloSystemException( e ,"error creating ElectronicsColorVariantProduct : "+e.getMessage(), 0 );
		}
	}
	
	public ElectronicsColorVariantProduct createElectronicsColorVariantProduct(final Map attributeValues)
	{
		return createElectronicsColorVariantProduct( getSession().getSessionContext(), attributeValues );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.discount</code> attribute.
	 * @return the discount - discount
	 */
	public Integer getDiscount(final SessionContext ctx, final Product item)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedProduct.getDiscount requires a session language", 0 );
		}
		return (Integer)item.getLocalizedProperty( ctx, PowerCapCoreConstants.Attributes.Product.DISCOUNT);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.discount</code> attribute.
	 * @return the discount - discount
	 */
	public Integer getDiscount(final Product item)
	{
		return getDiscount( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.discount</code> attribute. 
	 * @return the discount - discount
	 */
	public int getDiscountAsPrimitive(final SessionContext ctx, final Product item)
	{
		Integer value = getDiscount( ctx,item );
		return value != null ? value.intValue() : 0;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.discount</code> attribute. 
	 * @return the discount - discount
	 */
	public int getDiscountAsPrimitive(final Product item)
	{
		return getDiscountAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.discount</code> attribute. 
	 * @return the localized discount - discount
	 */
	public Map<Language,Integer> getAllDiscount(final SessionContext ctx, final Product item)
	{
		return (Map<Language,Integer>)item.getAllLocalizedProperties(ctx,PowerCapCoreConstants.Attributes.Product.DISCOUNT,C2LManager.getInstance().getAllLanguages());
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.discount</code> attribute. 
	 * @return the localized discount - discount
	 */
	public Map<Language,Integer> getAllDiscount(final Product item)
	{
		return getAllDiscount( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.discount</code> attribute. 
	 * @param value the discount - discount
	 */
	public void setDiscount(final SessionContext ctx, final Product item, final Integer value)
	{
		if( ctx == null || ctx.getLanguage() == null )
		{
			throw new JaloInvalidParameterException("GeneratedProduct.setDiscount requires a session language", 0 );
		}
		item.setLocalizedProperty(ctx, PowerCapCoreConstants.Attributes.Product.DISCOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.discount</code> attribute. 
	 * @param value the discount - discount
	 */
	public void setDiscount(final Product item, final Integer value)
	{
		setDiscount( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.discount</code> attribute. 
	 * @param value the discount - discount
	 */
	public void setDiscount(final SessionContext ctx, final Product item, final int value)
	{
		setDiscount( ctx, item, Integer.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.discount</code> attribute. 
	 * @param value the discount - discount
	 */
	public void setDiscount(final Product item, final int value)
	{
		setDiscount( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.discount</code> attribute. 
	 * @param value the discount - discount
	 */
	public void setAllDiscount(final SessionContext ctx, final Product item, final Map<Language,Integer> value)
	{
		item.setAllLocalizedProperties(ctx,PowerCapCoreConstants.Attributes.Product.DISCOUNT,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.discount</code> attribute. 
	 * @param value the discount - discount
	 */
	public void setAllDiscount(final Product item, final Map<Language,Integer> value)
	{
		setAllDiscount( getSession().getSessionContext(), item, value );
	}
	
	@Override
	public String getName()
	{
		return PowerCapCoreConstants.EXTENSIONNAME;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.offers</code> attribute.
	 * @return the offers - Offers Products
	 */
	public Boolean isOffers(final SessionContext ctx, final Product item)
	{
		return (Boolean)item.getProperty( ctx, PowerCapCoreConstants.Attributes.Product.OFFERS);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.offers</code> attribute.
	 * @return the offers - Offers Products
	 */
	public Boolean isOffers(final Product item)
	{
		return isOffers( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.offers</code> attribute. 
	 * @return the offers - Offers Products
	 */
	public boolean isOffersAsPrimitive(final SessionContext ctx, final Product item)
	{
		Boolean value = isOffers( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.offers</code> attribute. 
	 * @return the offers - Offers Products
	 */
	public boolean isOffersAsPrimitive(final Product item)
	{
		return isOffersAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.offers</code> attribute. 
	 * @param value the offers - Offers Products
	 */
	public void setOffers(final SessionContext ctx, final Product item, final Boolean value)
	{
		item.setProperty(ctx, PowerCapCoreConstants.Attributes.Product.OFFERS,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.offers</code> attribute. 
	 * @param value the offers - Offers Products
	 */
	public void setOffers(final Product item, final Boolean value)
	{
		setOffers( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.offers</code> attribute. 
	 * @param value the offers - Offers Products
	 */
	public void setOffers(final SessionContext ctx, final Product item, final boolean value)
	{
		setOffers( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.offers</code> attribute. 
	 * @param value the offers - Offers Products
	 */
	public void setOffers(final Product item, final boolean value)
	{
		setOffers( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.TopSeller</code> attribute.
	 * @return the TopSeller - Top Seller Products
	 */
	public Boolean isTopSeller(final SessionContext ctx, final Product item)
	{
		return (Boolean)item.getProperty( ctx, PowerCapCoreConstants.Attributes.Product.TOPSELLER);
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.TopSeller</code> attribute.
	 * @return the TopSeller - Top Seller Products
	 */
	public Boolean isTopSeller(final Product item)
	{
		return isTopSeller( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.TopSeller</code> attribute. 
	 * @return the TopSeller - Top Seller Products
	 */
	public boolean isTopSellerAsPrimitive(final SessionContext ctx, final Product item)
	{
		Boolean value = isTopSeller( ctx,item );
		return value != null ? value.booleanValue() : false;
	}
	
	/**
	 * <i>Generated method</i> - Getter of the <code>Product.TopSeller</code> attribute. 
	 * @return the TopSeller - Top Seller Products
	 */
	public boolean isTopSellerAsPrimitive(final Product item)
	{
		return isTopSellerAsPrimitive( getSession().getSessionContext(), item );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.TopSeller</code> attribute. 
	 * @param value the TopSeller - Top Seller Products
	 */
	public void setTopSeller(final SessionContext ctx, final Product item, final Boolean value)
	{
		item.setProperty(ctx, PowerCapCoreConstants.Attributes.Product.TOPSELLER,value);
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.TopSeller</code> attribute. 
	 * @param value the TopSeller - Top Seller Products
	 */
	public void setTopSeller(final Product item, final Boolean value)
	{
		setTopSeller( getSession().getSessionContext(), item, value );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.TopSeller</code> attribute. 
	 * @param value the TopSeller - Top Seller Products
	 */
	public void setTopSeller(final SessionContext ctx, final Product item, final boolean value)
	{
		setTopSeller( ctx, item, Boolean.valueOf( value ) );
	}
	
	/**
	 * <i>Generated method</i> - Setter of the <code>Product.TopSeller</code> attribute. 
	 * @param value the TopSeller - Top Seller Products
	 */
	public void setTopSeller(final Product item, final boolean value)
	{
		setTopSeller( getSession().getSessionContext(), item, value );
	}
	
}
