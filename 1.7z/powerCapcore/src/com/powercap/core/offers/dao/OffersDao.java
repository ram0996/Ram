/**
 *
 */
package com.powercap.core.offers.dao;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.promotions.model.ProductPercentageDiscountPromotionModel;
import de.hybris.platform.servicelayer.internal.dao.AbstractItemDao;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.SearchResult;

import java.util.List;

import org.apache.log4j.Logger;


/**
 * @author Pratik
 *
 */
public class OffersDao extends AbstractItemDao
{


	private static final Logger LOG = Logger.getLogger(OffersDao.class);

	/**
	 * @return
	 */
	public List<ProductModel> retrieveProducts()
	{
		LOG.info("inside retriveProduct");
		final String queryString = new StringBuilder(
				"SELECT DISTINCT{P:PK} FROM {Product AS P JOIN ProductPromotionRelation AS PPR ON {P:PK} ={PPR:SOURCE} JOIN ProductPromotion AS PP ON {PP:PK}={PPR:TARGET}},{ProductPercentageDiscountPromotion AS PPDP} where {P:catalogversion} in ({{ select {pk} from {CatalogVersion} where {version}='Online' and {catalog} in ({{select {pk} from {catalog} where {id}='powerCapProductCatalog'}})}}) and {PP:code} = {PPDP:code} and {PPDP:enabled} = true")
						.toString();
		final FlexibleSearchQuery query = new FlexibleSearchQuery(queryString);
		final SearchResult searchResult = flexibleSearchService.search(query);
		final List<ProductModel> productList = searchResult.getResult();
		return productList;
	}

	/**
	 * @param retrievedCode
	 * @return
	 */
	@SuppressWarnings("boxing")
	public double retrieveProductDiscount(final String retrievedCode)
	{
		LOG.info("inside retrieveProductDiscount");
		double discount = 0;
		//	final Offers offerProduct = new Offers();

		final String queryString = new StringBuilder(
				"SELECT {PPDP:PK} FROM {Product AS P JOIN ProductPromotionRelation AS PPR ON {P:PK} ={PPR:SOURCE} JOIN ProductPromotion AS PP ON {PP:PK}={PPR:TARGET}},{ProductPercentageDiscountPromotion AS PPDP} where {P:catalogversion} in ({{ select {pk} from {CatalogVersion} where {version}='Online' and {catalog} in ({{select {pk} from {catalog} where {id}='powerCapProductCatalog'}})}}) and {PP:code} = {PPDP:code} AND {P:code} =?code")
						.toString();
		final FlexibleSearchQuery query = new FlexibleSearchQuery(queryString);
		query.addQueryParameter("code", retrievedCode);
		final SearchResult searchResult = flexibleSearchService.search(query);
		final List<ProductPercentageDiscountPromotionModel> discountList = searchResult.getResult();

		LOG.info("Converting to array");
		ProductPercentageDiscountPromotionModel[] s = new ProductPercentageDiscountPromotionModel[discountList.size()];
		s = discountList.toArray(s);

		for (final ProductPercentageDiscountPromotionModel abc : s)
		{
			LOG.info("Printing Discount");
			LOG.info("discount=" + abc.getPercentageDiscount());
		}

		LOG.info("Above for each loop in offersDao");
		for (final ProductPercentageDiscountPromotionModel value : discountList)
		{
			LOG.info("inside for of offersDao");

			discount = value.getPercentageDiscount();
			LOG.info("retrieved discount");
			if (discount != 0)
			{
				return discount;
			}
		}

		return discount;
	}


}
