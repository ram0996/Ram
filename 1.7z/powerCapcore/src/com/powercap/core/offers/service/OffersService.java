/**
 *
 */
package com.powercap.core.offers.service;

import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.jalo.order.price.PriceInformation;
import de.hybris.platform.product.PriceService;
import de.hybris.platform.product.ProductService;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.powercap.core.offers.dao.OffersDao;


/**
 * @author Pratik
 *
 */
public class OffersService
{
	private Converter<ProductModel, ProductData> productConverter;
	private PriceService priceService;
	private ProductService productService;


	/**
	 * @return the productService
	 */
	public ProductService getProductService()
	{
		return productService;
	}


	/**
	 * @param productService
	 *           the productService to set
	 */
	public void setProductService(final ProductService productService)
	{
		this.productService = productService;
	}






	/**
	 * @return the priceService
	 */
	public PriceService getPriceService()
	{
		return priceService;
	}


	/**
	 * @param priceService
	 *           the priceService to set
	 */
	public void setPriceService(final PriceService priceService)
	{
		this.priceService = priceService;
	}


	/**
	 * @return the productConverter
	 */
	public Converter<ProductModel, ProductData> getProductConverter()
	{
		return productConverter;
	}


	/**
	 * @param productConverter
	 *           the productConverter to set
	 */
	public void setProductConverter(final Converter<ProductModel, ProductData> productConverter)
	{
		this.productConverter = productConverter;
	}

	private static final Logger LOG = Logger.getLogger(OffersService.class);

	@Resource(name = "OffersDao")
	private OffersDao offersDao;


	public List<Offers> retrieveProducts()
	{
		final List<ProductModel> productWithOffers = offersDao.retrieveProducts();

		ProductData data = new ProductData();

		final List<Offers> productLst = new ArrayList<Offers>();

		for (final ProductModel product : productWithOffers)
		{
			final Offers offerProduct = new Offers();
			double discountRate = 0.0;

			LOG.info("Promotion" + product.getPromotions());




			if (product.getPicture() != null)
			{

				offerProduct.setImageUrl(product.getPicture().getUrl());

			}
			final List<PriceInformation> prices = getPriceService().getPriceInformationsForProduct(product);
			if (!prices.isEmpty())
			{
				final PriceInformation price = prices.iterator().next();

				offerProduct.setOriginalPrice(price.getPriceValue().getValue());
				offerProduct.setCurrency(price.getPriceValue().getCurrencyIso());
			}

			data = getProductConverter().convert(product);

			LOG.info("Promotion" + product.getPromotions());



			offerProduct.setCode(data.getCode());
			offerProduct.setName(data.getName());
			offerProduct.setProductUrl(data.getUrl());

			//LOG.info("OFFER PRODUCT=" + offerProduct.getCode());
			//LOG.info("OFFER PRODUCT price=" + offerProduct.getOriginalPrice());
			LOG.info("Image URL=" + offerProduct.getImageUrl());
			final String RetrievedCode = offerProduct.getCode();

			discountRate = offersDao.retrieveProductDiscount(RetrievedCode);

			offerProduct.setDiscountRate(discountRate);

			final double priceAfterDiscount = ((offerProduct.getOriginalPrice()) - ((discountRate * (offerProduct.getOriginalPrice())) / 100));

			offerProduct.setDiscountedPrice(priceAfterDiscount);


			productLst.add(offerProduct);



		}
		return productLst;


	}

}
