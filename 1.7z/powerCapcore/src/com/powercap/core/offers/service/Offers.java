/**
 *
 */
package com.powercap.core.offers.service;

/**
 * @author Pratik
 *
 */
public class Offers
{

	String imageUrl;
	String productUrl;
	String code;
	String name;
	double originalPrice;
	double discountedPrice;
	String currency;
	double discountRate;


	/**
	 * @return the discountRate
	 */
	public double getDiscountRate()
	{
		return discountRate;
	}

	/**
	 * @param discountRate
	 *           the discountRate to set
	 */
	public void setDiscountRate(final double discountRate)
	{
		this.discountRate = discountRate;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency()
	{
		return currency;
	}

	/**
	 * @param currency
	 *           the currency to set
	 */
	public void setCurrency(final String currency)
	{
		this.currency = currency;
	}

	/**
	 * @return the imageUrl
	 */
	public String getImageUrl()
	{
		return imageUrl;
	}

	/**
	 * @param imageUrl
	 *           the imageUrl to set
	 */
	public void setImageUrl(final String imageUrl)
	{
		this.imageUrl = imageUrl;
	}

	/**
	 * @return the productUrl
	 */
	public String getProductUrl()
	{
		return productUrl;
	}

	/**
	 * @param productUrl
	 *           the productUrl to set
	 */
	public void setProductUrl(final String productUrl)
	{
		this.productUrl = productUrl;
	}

	/**
	 * @return the code
	 */
	public String getCode()
	{
		return code;
	}

	/**
	 * @param code
	 *           the code to set
	 */
	public void setCode(final String code)
	{
		this.code = code;
	}

	/**
	 * @return the name
	 */
	public String getName()
	{
		return name;
	}

	/**
	 * @param name
	 *           the name to set
	 */
	public void setName(final String name)
	{
		this.name = name;
	}


	/**
	 * @return the originalPrice
	 */
	public double getOriginalPrice()
	{
		return originalPrice;
	}

	/**
	 * @param originalPrice
	 *           the originalPrice to set
	 */
	public void setOriginalPrice(final double originalPrice)
	{
		this.originalPrice = originalPrice;
	}

	/**
	 * @return the discountedPrice
	 */
	public double getDiscountedPrice()
	{
		return discountedPrice;
	}

	/**
	 * @param discountedPrice
	 *           the discountedPrice to set
	 */
	public void setDiscountedPrice(final double discountedPrice)
	{
		this.discountedPrice = discountedPrice;
	}

	public Double getValue()
	{
		return value;
	}

	/**
	 * @param value
	 *           the value to set
	 */
	public void setValue(final Double value)
	{
		this.value = value;
	}

	Double value;
}
