/**
 *
 */
package com.powercap.core.Topsellers.service;

import de.hybris.platform.commercefacades.product.data.ProductData;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.jalo.order.price.PriceInformation;
import de.hybris.platform.product.PriceService;
import de.hybris.platform.product.ProductService;
import de.hybris.platform.servicelayer.dto.converter.Converter;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.powercap.core.Topsellers.dao.TopsellersDao;


/**
 * @author smarokky
 *
 */
public class TopsellersService
{
	private Converter<ProductModel, ProductData> productConverter;
	private PriceService priceService;
	private ProductService productService;

	/**
	 * @return the productService
	 */
	public ProductService getProductService()
	{
		return productService;
	}


	/**
	 * @param productService
	 *           the productService to set
	 */
	public void setProductService(final ProductService productService)
	{
		this.productService = productService;
	}






	/**
	 * @return the priceService
	 */
	public PriceService getPriceService()
	{
		return priceService;
	}


	/**
	 * @param priceService
	 *           the priceService to set
	 */
	public void setPriceService(final PriceService priceService)
	{
		this.priceService = priceService;
	}


	/**
	 * @return the productConverter
	 */
	public Converter<ProductModel, ProductData> getProductConverter()
	{
		return productConverter;
	}


	/**
	 * @param productConverter
	 *           the productConverter to set
	 */
	public void setProductConverter(final Converter<ProductModel, ProductData> productConverter)
	{
		this.productConverter = productConverter;
	}


	private static final Logger LOG = Logger.getLogger(TopsellersService.class);
	@Resource(name = "TopsellersDao")
	private TopsellersDao topSellersDao;


	public List<TopsellersData> productreturnedlist()
	{
		final List<ProductModel> listproducts = topSellersDao.findtopsellersproduct();
		ProductData data = new ProductData();
		final List<TopsellersData> topSellersData = new ArrayList<TopsellersData>();
		for (final ProductModel pro : listproducts)
		{

			final TopsellersData tsdata = new TopsellersData();

			if (pro.getPicture() != null)
			{

				tsdata.setImageUrl(pro.getPicture().getUrl());
			}
			final List<PriceInformation> prices = getPriceService().getPriceInformationsForProduct(pro);
			if (!prices.isEmpty())
			{
				final PriceInformation price = prices.iterator().next();

				LOG.info("price--->" + price.getPriceValue().getValue());
				LOG.info("iso--->" + price.getPriceValue().getCurrencyIso());
				tsdata.setValue(price.getPriceValue().getValue());
				tsdata.setCurrency(price.getPriceValue().getCurrencyIso());
			}

			data = getProductConverter().convert(pro);

			tsdata.setCode(data.getCode());
			tsdata.setName(data.getName());
			tsdata.setProductUrl(data.getUrl());

			tsdata.setPrice(data.getPrice());
			topSellersData.add(tsdata);
		}




		return topSellersData;
	}

}
