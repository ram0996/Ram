/**
 *
 */
package com.powercap.core.Topsellers.dao;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.internal.dao.AbstractItemDao;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.SearchResult;

import java.util.List;

import org.apache.log4j.Logger;


/**
 * @author smarokky
 *
 */
public class TopsellersDao extends AbstractItemDao
{
	private static final Logger LOG = Logger.getLogger(TopsellersDao.class);

	public List<ProductModel> findtopsellersproduct()

	{
		LOG.info("Dao");
		final String queryString = new StringBuilder("SELECT {PK} FROM {Product} where {TOPSELLER}= true").toString();
		final FlexibleSearchQuery query = new FlexibleSearchQuery(queryString);
		final SearchResult searchResult = flexibleSearchService.search(query);
		final List<ProductModel> productList = searchResult.getResult();
		return productList;
	}
}
