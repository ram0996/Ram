/*
 * ----------------------------------------------------------------
 * --- WARNING: THIS FILE IS GENERATED AND WILL BE OVERWRITTEN! ---
 * --- Generated at Jun 15, 2017 3:26:18 PM                     ---
 * ----------------------------------------------------------------
 */
package com.powercap.initialdata.constants;

/**
 * @deprecated use constants in Model classes instead
 */
@Deprecated
@SuppressWarnings({"unused","cast","PMD"})
public class GeneratedPowerCapInitialDataConstants
{
	public static final String EXTENSIONNAME = "powerCapinitialdata";
	
	protected GeneratedPowerCapInitialDataConstants()
	{
		// private constructor
	}
	
	
}
